﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RockPaperScissorsBoom.Server.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
