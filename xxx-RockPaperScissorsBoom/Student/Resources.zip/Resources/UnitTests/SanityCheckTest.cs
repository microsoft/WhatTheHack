using Xunit;

namespace UnitTests
{
    public class SanityCheckTest
    {
        [Fact]
        public void ThisShouldNeverFail()
        {
        }
    }
}
