﻿namespace RockPaperScissor.Core.Game.Results
{
    public enum MatchOutcome
    {
        Player1,
        Player2,
        Neither
    }
}