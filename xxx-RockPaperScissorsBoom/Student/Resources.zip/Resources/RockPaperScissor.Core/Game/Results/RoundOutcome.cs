﻿namespace RockPaperScissor.Core.Game.Results
{
    public enum RoundOutcome
    {
        Loss = 0,
        Win = 1,
        Tie = 2
    }
}