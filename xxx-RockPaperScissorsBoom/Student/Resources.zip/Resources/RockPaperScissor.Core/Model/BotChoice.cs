﻿using RockPaperScissor.Core.Game;

namespace RockPaperScissor.Core.Model
{
    public class BotChoice
    {
        public Decision Decision { get; set; }
    }
}