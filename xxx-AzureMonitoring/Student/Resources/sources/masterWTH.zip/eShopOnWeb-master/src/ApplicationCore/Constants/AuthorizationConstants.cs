﻿namespace Microsoft.eShopWeb.ApplicationCore.Constants
{
    public class AuthorizationConstants
    {
        public static class Roles
        {
            public const string ADMINISTRATORS = "Administrators";
        }

        public const string DEFAULT_PASSWORD = "Pass@word1";
    }
}
